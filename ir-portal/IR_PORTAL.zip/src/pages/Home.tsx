import React, { useState } from 'react';
import Layout from '../components/Layout';
import HeroBanner from '../components/HeroBanner';
import RecommendedProjects from '../components/RecommendedProjects';
import CityCategories from '../components/CityCategories';
import PropertyGrid from '../components/PropertyGrid';
import UpcomingProjects from '../components/UpcomingProjects';
import PostedBy from '../components/PostedBy';
import PriceTrendFooter from '../components/PriceTrendFooter';
import LatestArticles from '../components/LatestArticles';
import ViewToggle from '../components/ViewToggle';
import PopularBuilders from '../components/PopularBuilders';

import { properties } from '../data/properties';
import { Property } from '../types';

const Home: React.FC = () => {
  // Search input state (connected to header input via Layout)
  const [searchQuery, setSearchQuery] = useState('');

  // Favorite property IDs
  const [favorites, setFavorites] = useState<Set<string>>(new Set());

  // View toggle: grid | list | map
  const [selectedView, setSelectedView] = useState<'grid' | 'list' | 'map'>('grid');

  // Filters: Price, Size, Location
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 5000000]);
  const [sizeRange, setSizeRange] = useState<[number, number]>([0, 5000]);
  const [location, setLocation] = useState<string>('');

  // Filtered property list
  const filteredProperties: Property[] = properties.filter((property) =>
    property.price >= priceRange[0] &&
    property.price <= priceRange[1] &&
    property.sqft >= sizeRange[0] &&
    property.sqft <= sizeRange[1] &&
    (location === '' || property.location.toLowerCase().includes(location.toLowerCase()))
  );

  return (
    <Layout searchQuery={searchQuery} setSearchQuery={setSearchQuery}>
      {/* 1. Hero Banner */}
      <HeroBanner />

      {/* 2. Recommended Projects */}
      <RecommendedProjects />

      {/* 3. Explore Cities */}
      <CityCategories />

      {/* 4. Property Grid with filters + view toggle */}
      <PropertyGrid
        properties={filteredProperties}
        priceRange={priceRange}
        setPriceRange={setPriceRange}
        sizeRange={sizeRange}
        setSizeRange={setSizeRange}
        location={location}
        setLocation={setLocation}
        selectedView={selectedView}
        setSelectedView={setSelectedView}
        favorites={favorites}
        setFavorites={setFavorites}
      />

      {/* 5. Upcoming Launches */}
      <UpcomingProjects />

      {/* 6. Property Posters: Builders / Owners / Dealers */}
      <PostedBy />

      {/* 7. Market Trends (Location price footers etc.) */}
      <PriceTrendFooter />

      {/* 8. Popular Builders in India */}
      <PopularBuilders />

      {/* 9. Latest Articles / News / Blog */}
      <LatestArticles />
    </Layout>
  );
};

export default Home;
// Compare this snippet from ir-portal/src/components/ViewToggle.tsx: