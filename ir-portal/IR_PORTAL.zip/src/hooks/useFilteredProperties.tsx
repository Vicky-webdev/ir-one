import { useMemo } from "react";
import { Property } from "../types";

export const useFilteredProperties = (
  properties: Property[],
  priceRange: [number, number],
  searchQuery: string
): Property[] => {
  return useMemo(
    () =>
      properties.filter(
        (p) =>
          p.price >= priceRange[0] &&
          p.price <= priceRange[1] &&
          p.title.toLowerCase().includes(searchQuery.toLowerCase())
      ),
    [properties, priceRange, searchQuery]
  );
};
