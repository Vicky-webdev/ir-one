import React, { useState, useEffect } from 'react';

interface FilterPanelProps {
  priceRange: [number, number];
  setPriceRange: (range: [number, number]) => void;
  sizeRange: [number, number];
  setSizeRange: (range: [number, number]) => void;
  location: string;
  setLocation: (loc: string) => void;
  sortBy: string;
  setSortBy: (sort: string) => void;
  showFavorites: boolean;
  setShowFavorites: (show: boolean) => void;
  resetFilters: () => void;
}

const FilterPanel: React.FC<FilterPanelProps> = ({
  priceRange,
  setPriceRange,
  sizeRange,
  setSizeRange,
  location,
  setLocation,
  sortBy,
  setSortBy,
  showFavorites,
  setShowFavorites,
  resetFilters,
}) => {
  const [searchTerm, setSearchTerm] = useState(location);

  useEffect(() => {
    const delayDebounce = setTimeout(() => {
      setLocation(searchTerm);
    }, 500);

    return () => clearTimeout(delayDebounce);
  }, [searchTerm]);

  return (
    <div className="grid md:grid-cols-3 gap-4">
      <div>
        <label className="text-sm font-semibold">Price Range</label>
        <input
          type="range"
          min="0"
          max="5000000"
          step="100000"
          value={priceRange[1]}
          onChange={(e) => setPriceRange([priceRange[0], parseInt(e.target.value)])}
          className="w-full"
        />
        <div className="text-xs text-gray-500 mt-1">Up to ₹{priceRange[1].toLocaleString()}</div>
      </div>

      <div>
        <label className="text-sm font-semibold">Size Range (sqft)</label>
        <input
          type="range"
          min="100"
          max="10000"
          step="100"
          value={sizeRange[1]}
          onChange={(e) => setSizeRange([sizeRange[0], parseInt(e.target.value)])}
          className="w-full"
        />
        <div className="text-xs text-gray-500 mt-1">Up to {sizeRange[1]} sqft</div>
      </div>

      <div>
        <label className="text-sm font-semibold">Location</label>
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full border px-2 py-1 rounded"
          placeholder="Search by location"
        />
      </div>

      <div>
        <label className="text-sm font-semibold">Sort By</label>
        <select
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value)}
          className="w-full border px-2 py-1 rounded"
        >
          <option value="">Select</option>
          <option value="priceLowHigh">Price: Low to High</option>
          <option value="priceHighLow">Price: High to Low</option>
          <option value="size">Size: Largest First</option>
        </select>
      </div>

      <div className="flex items-center gap-2 mt-4">
        <input
          type="checkbox"
          checked={showFavorites}
          onChange={(e) => setShowFavorites(e.target.checked)}
        />
        <label>Show Favorites</label>
      </div>

      <div className="mt-4">
        <button
          onClick={resetFilters}
          className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600"
        >
          Reset Filters
        </button>
      </div>
    </div>
  );
};

export default FilterPanel;