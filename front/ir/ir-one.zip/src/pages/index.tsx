import Hero from '../components/home/Hero';
 

const HomePage = () => {
    return (
      <div className="px-4 sm:px-6 lg:px-8">
       
        <Hero />
      </div>
    );
  };
  
  export default HomePage;
  