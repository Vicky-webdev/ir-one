const PropertyDetailsPage = () => {
    return <div>Property Detail Page</div>;
  };
  
  export default PropertyDetailsPage;
  