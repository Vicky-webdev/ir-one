//  constants/navigation.ts
// ----------------------------------
export const NAV_LINKS = ['Buy', 'Rent', 'Sell', 'Mortgage'];