const PropertiesPage = () => {
    return <div>Properties Listing Page</div>;
  };
  
  export default PropertiesPage;
  